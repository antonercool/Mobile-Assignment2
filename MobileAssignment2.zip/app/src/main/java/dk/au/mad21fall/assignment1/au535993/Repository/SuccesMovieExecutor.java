package dk.au.mad21fall.assignment1.au535993.Repository;

import android.content.Context;

import dk.au.mad21fall.assignment1.au535993.Database.MovieEntity;

public interface SuccesMovieExecutor {
    void ExecuteSucces(MovieEntity entity, Context context);
}
