package dk.au.mad21fall.assignment1.au535993.EditActivity.ViewModel;

import dk.au.mad21fall.assignment1.au535993.DetailsActivity.ViewModel.DetailsViewModel;

public class EditViewModel extends DetailsViewModel {
}
