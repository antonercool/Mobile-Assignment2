package dk.au.mad21fall.assignment1.au535993.ListActivity.MovieItemClickedListener;

public interface IMovieItemClickedListener {

    void onMovieItemClicked(int index);
}
