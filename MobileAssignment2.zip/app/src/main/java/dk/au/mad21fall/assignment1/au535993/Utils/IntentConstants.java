package dk.au.mad21fall.assignment1.au535993.Utils;

public class IntentConstants {
    public final static String DETAILS = "DETAILS";
    public final static String EDIT = "EDIT";

}
